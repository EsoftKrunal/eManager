﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class eReports_S115_S115_List : System.Web.UI.Page
{
    string FormNo = "S115";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindFormDetails();
            BindFleet();
            BindVessels();
            BindList();
        }
    }
    public void BindFormDetails()
    {
        DataTable dt = Common.Execute_Procedures_Select_ByQuery("SELECT * FROM [MTMPMS].[DBO].[ER_Master] WHERE [FormNo]='" + FormNo + "'");
        lblReportName.Text = dt.Rows[0]["FormName"].ToString();

    }
    public void BindFleet()
    {
        try
        {
            DataTable dtFleet = Common.Execute_Procedures_Select_ByQuery("SELECT FleetId,FleetName as Name FROM SHIPSOFT.dbo.FleetMaster");
            this.ddlFleet.DataSource = dtFleet;
            this.ddlFleet.DataValueField = "FleetId";
            this.ddlFleet.DataTextField = "Name";
            this.ddlFleet.DataBind();
            ddlFleet.Items.Insert(0, new ListItem("< All Fleet >", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void BindVessels()
    {
        DataTable dtVessels = new DataTable();
        string strvessels = "SELECT VesselId,VesselCode,VesselName FROM [ShipSoft].[dbo].[Vessel] WHERE VesselStatusId=1 AND VesselId not in (41,43,44) ORDER BY VesselName";
        dtVessels = Common.Execute_Procedures_Select_ByQuery(strvessels);
        if (dtVessels.Rows.Count > 0)
        {
            ddlVessels.DataSource = dtVessels;
            ddlVessels.DataTextField = "VesselName";
            ddlVessels.DataValueField = "VesselCode";
            ddlVessels.DataBind();
        }
        else
        {
            ddlVessels.DataSource = null;
            ddlVessels.DataBind();
        }
        ddlVessels.Items.Insert(0, new ListItem("< All Vessel >", ""));
    }
    protected void BindList()
    {
        string sqL = "SELECT ROW_NUMBER() OVER(Order By R.ReportId) AS SrNo,(CASE WHEN ISNULL(IS_CLOSED,'N')='Y' THEN 'N' ELSE 'Y' END) as Edit_ALLOWED, R.[ReportId],[ReportNo],AccidentSeverity=(CASE WHEN AccidentSeverity=1 THEN 'Minor' WHEN AccidentSeverity=2 THEN 'Major' WHEN AccidentSeverity=3 THEN 'Severe' ELSE '' END) ,PORT,INCIDENTDATE,REPORTDATE,R.CreatedBy, R.CreatedOn,R.VesselCode,(CASE WHEN ISNULL(O.IS_CLOSED,'N')='N' THEN 'Open' ELSE 'Closed' END) as Status FROM [MTMPMS].[DBO].[ER_" + FormNo + "_Report] R " +
                     "LEFT JOIN [MTMPMS].[DBO].[ER_S115_Report_Office] O ON O.ReportId = R.ReportId AND O.VesselCode = R.VesselCode " +
                     "WHERE ISNULL(O.Status,'A') = 'A'";

        if (txtFd.Text.Trim() != "")
        {
            sqL += " AND INCIDENTDATE >='" + txtFd.Text.Trim() + "'";
        }
        if (txtTD.Text.Trim() != "")
        {
            sqL += " AND INCIDENTDATE <='" + txtTD.Text.Trim() + "'";
        }
        //if (txtPort.Text.Trim() != "")
        //{
        //    sqL += " AND Port  LIKE '" + txtPort.Text.Trim() + "%'";
        //}
        

        string selectedValues = "";

        foreach (ListItem li in cblSeverity.Items)
        {
            //if (li.Selected && li.Value == "0")
            //{
            //    break;
            //}
            //else
            //{
                if (li.Selected)
                {
                    selectedValues = selectedValues + li.Value + ",";
                }
            //}
        }
        if (selectedValues.Trim() != "")
        {
            selectedValues = selectedValues.TrimEnd(',');
        }

        if (selectedValues.Trim() != "")
        {
            sqL += " AND AccidentSeverity IN (" + selectedValues + ") ";
        }

        //if (cblSeverity..SelectedValue != "0" && )
        //{
        //    sqL += " AND AccidentSeverity=" + 1;
        //}
        //if (RadioButton2.Checked)
        //{
        //    sqL += " AND AccidentSeverity=" + 2;
        //}
        //if (RadioButton3.Checked)
        //{
        //    sqL += " AND AccidentSeverity=" + 3;
        //}

        if (ddlStatus.SelectedValue.Trim() != "0")
        {
            sqL += " AND ISNULL(O.Is_Closed,'N') = '" + ddlStatus.SelectedValue.Trim() + "' ";
        }

        string WhereCondition = " ";
        if (ddlFleet.SelectedIndex != 0)
        {
            if (ddlVessels.SelectedIndex == 0)
            {
                WhereCondition = WhereCondition + "AND R.VesselCode IN (SELECT VesselCode FROM  ShipSoft.dbo.Vessel WHERE FleetId = " + ddlFleet.SelectedValue + ")";
            }
            else
            {
                WhereCondition = WhereCondition + "AND R.VesselCode = '" + ddlVessels.SelectedValue.ToString() + "' ";
            }
        }
        else if (ddlVessels.SelectedIndex != 0)
        {
            WhereCondition = WhereCondition + "AND R.VesselCode = '" + ddlVessels.SelectedValue.ToString() + "' ";
        }

        sqL += WhereCondition;

        DataTable dt = Common.Execute_Procedures_Select_ByQuery(sqL);
        if (dt != null)
        {
            rptReports.DataSource = dt;
            rptReports.DataBind();
        }
    }
    protected void lnkReport_OnClick(object sender, EventArgs e)
    {

    }

    protected void btnShow_Click(object sender, EventArgs e)
    {
        BindList();
    }

    protected void ddlFleet_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlFleet.SelectedIndex != 0)
        {
            DataTable dtVessels = new DataTable();
            string strvessels = "SELECT VesselId,VesselCode,VesselName FROM [ShipSoft].[dbo].[Vessel] WHERE FleetId = " + ddlFleet.SelectedValue + " AND VesselId not in (41,43,44) ORDER BY VesselName";
            dtVessels = Common.Execute_Procedures_Select_ByQuery(strvessels);
            ddlVessels.Items.Clear();
            if (dtVessels.Rows.Count > 0)
            {
                ddlVessels.DataSource = dtVessels;
                ddlVessels.DataTextField = "VesselCode";
                ddlVessels.DataValueField = "VesselCode";
                ddlVessels.DataBind();
            }
            else
            {
                ddlVessels.DataSource = null;
                ddlVessels.DataBind();
            }
            ddlVessels.Items.Insert(0, "< All >");
        }
        else
        {
            ddlVessels.Items.Clear();
            BindVessels();
        }
    }
}